package com.example.anilistify

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
